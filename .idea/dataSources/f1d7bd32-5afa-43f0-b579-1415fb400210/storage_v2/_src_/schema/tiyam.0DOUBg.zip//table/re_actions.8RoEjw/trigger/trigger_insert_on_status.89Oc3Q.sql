create definer = root@localhost trigger trigger_insert_on_status
  after INSERT
  on re_actions
  for each row
BEGIN
                SET @COUNT=(SELECT COUNT(nid) FROM totals WHERE nid=NEW.nid );
                IF @COUNT=0 THEN
                    INSERT INTO totals ( `nid`, `like`,`dislike`, `total`, `wilson`, `created_at`)
                    VALUES( NEW.nid , IF(NEW.status=1, 1, 0), IF(NEW.status=2, 2, 0), 1, IF(NEW.status=1, 1, 0), NOW());
                ELSE
                    UPDATE totals SET 
                        totals.like = IF(NEW.status=1, totals.like + 1, totals.like),
                        totals.dislike = IF(NEW.status=2, totals.dislike + 1, totals.dislike),
                        totals.total = IF(NEW.status!=0, totals.total + 1, totals.total)
                    WHERE (nid = NEW.nid);
                 END IF;
            END;

